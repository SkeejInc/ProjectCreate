StartupEvents.registry("item", event => {
	event.create("profession_stub")
	event.create("incomplete_metal_scrap")
})