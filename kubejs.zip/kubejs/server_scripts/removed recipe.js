console.info("Remove")

ServerEvents.recipes(event => {

	event.remove({id: "immersiveengineering:crafting/alloybrick"})
    event.remove({id: "immersiveengineering:crafting/alloybrick_to slab"})
    event.remove({id: "immersiveengineering:crafting/alloybrick_from_slab"})
    event.remove({id: "immersiveengineering:crafting/plate_(\w+)_hammering"})
    event.remove({id: "create:smelting/scoria"})
})