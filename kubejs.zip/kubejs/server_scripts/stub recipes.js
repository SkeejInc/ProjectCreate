ServerEvents.recipes(event => {
    const CreateCobbleGeneratorRecipe = (items, fluids, outputs) => {
            // This is horrible, and I have to do it bless KubeJS
            for (let stubs = 0; stubs < 7; stubs++) {
                let ingredients = fluids.map((fluid) => (Fluid.of(fluid, 2 ** stubs)))
                    .concat(items.map((item) => (Item.of(item))))
    
                for (let i = 0; i < stubs; i++) {
                    ingredients.push(Item.of(KJ("profession_stub")))
                }
    
                let ingredients_2 = fluids.map((fluid) => (Fluid.of(fluid, 2 ** stubs)))
                .concat(items.map((item) => (Item.of(item))))
    
                if (stubs > 0) {
                    ingredients_2.push(Item.of(KJ("profession_stub"), stubs))
                }
    
                let results = ingredients_2.concat(outputs.map((item) => (Item.of(item, 2 ** stubs))))
    
                event.recipes.createMixing(results, ingredients)
            }
        }
    
        CreateCobbleGeneratorRecipe([], [MC("lava"), MC("water")], [MC("cobblestone")])
    
        CreateCobbleGeneratorRecipe([], [MC("lava"), C("honey")], [C("limestone")])
    
        CreateCobbleGeneratorRecipe([], [MC("lava"), C("chocolate")], [C("scoria")])
    
        CreateCobbleGeneratorRecipe([MC("blue_ice"), MC("soul_soil")], [MC("lava")], [MC("basalt")])
    })