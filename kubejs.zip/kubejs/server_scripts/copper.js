console.info("Copper")

ServerEvents.recipes(event => {
	event.recipes.createSplashing([MC("exposed_copper")], [MC("copper_block")])
	event.recipes.createSplashing([MC("weathered_copper")], [MC("exposed_copper")])
	event.recipes.createSplashing([MC("oxidized_copper")], [MC("weathered_copper")])
})