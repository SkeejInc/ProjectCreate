console.info("Shaped Recipe")

ServerEvents.recipes(event => {
    event.shaped(SP("bomb_blue"), [
        "AAA",
        "ABA",
        "AAA"
    ], {
        A: SP("bomb"),
        B: MC("nether_star"),
})
})