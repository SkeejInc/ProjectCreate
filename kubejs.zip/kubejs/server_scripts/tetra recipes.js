console.info("Sequence")

ServerEvents.recipes(event => {
    event.recipes.createSequencedAssembly(
        [T("metal_scrap" ,4)],
        MC("netherite_scrap"),
        [
            event.recipes.createPressing([KJ("incomplete_metal_scrap")], [KJ("incomplete_metal_scrap")]),
            event.recipes.createDeploying([KJ("incomplete_metal_scrap")], [KJ("incomplete_metal_scrap"), T("vent_plate")]),
            event.recipes.createPressing([KJ("incomplete_metal_scrap")], [KJ("incomplete_metal_scrap")]),

        ]
    ).transitionalItem(KJ("incomplete_metal_scrap")).loops(2)
    })